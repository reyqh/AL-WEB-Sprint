import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  NavLink,
  useParams,
} from "react-router-dom";

import { 
  useState 
} from "react";

import "./App.css";

const navigation = [
  { name: "Dashboard", path: "/", icon: "▦" },
  { name: "Applications", path: "/applications", icon: "▤" },
  { name: "AI Audit Console", path: "/ai-audit", icon: "◈" },
  { name: "Stress Testing", path: "/stress-testing", icon: "⌁" },
  { name: "Loan Approval", path: "/approval", icon: "✓" },
];



const applicationsData = [
  {
    id: "APP-2026-001",
    name: "James Murphy",
    property: "Residential",
    amount: "€285,000",
    status: "Under Review",
    risk: "Low",
    askingPrice: 300000,
    estimatedValuation: 310000,
    annualIncome: 85000,
    monthlyDebts: 450,
    monthlyMortgage: 1450,
  },
  {
    id: "APP-2026-002",
    name: "Sarah O'Brien",
    property: "First-Time Buyer",
    amount: "€320,000",
    status: "Pending",
    risk: "Medium",
    askingPrice: 340000,
    estimatedValuation: 335000,
    annualIncome: 90000,
    monthlyDebts: 600,
    monthlyMortgage: 1650,
  },
  {
    id: "APP-2026-003",
    name: "Daniel Walsh",
    property: "Residential",
    amount: "€410,000",
    status: "Approved",
    risk: "Low",
    askingPrice: 440000,
    estimatedValuation: 450000,
    annualIncome: 125000,
    monthlyDebts: 500,
    monthlyMortgage: 2100,
  },
  {
    id: "APP-2026-004",
    name: "Emma Kelly",
    property: "Buy-to-Let",
    amount: "€195,000",
    status: "Under Review",
    risk: "High",
    askingPrice: 220000,
    estimatedValuation: 205000,
    annualIncome: 55000,
    monthlyDebts: 850,
    monthlyMortgage: 1100,
  },
  {
    id: "APP-2026-005",
    name: "Michael Byrne",
    property: "First-Time Buyer",
    amount: "€265,000",
    status: "Pending",
    risk: "Medium",
    askingPrice: 280000,
    estimatedValuation: 275000,
    annualIncome: 72000,
    monthlyDebts: 400,
    monthlyMortgage: 1350,
  },
];




function Layout({ children }) {
  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">AL</div>
          <div>
            <h2>Agentic Lender</h2>
            <span>Multi-View Portal</span>
          </div>
        </div>

        <div className="nav-section">
          <p className="nav-label">WORKSPACE</p>

          {navigation.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === "/"}
              className={({ isActive }) =>
                isActive ? "nav-link active" : "nav-link"
              }
            >
              <span className="nav-icon">{item.icon}</span>
              {item.name}
            </NavLink>
          ))}
        </div>

        <div className="sidebar-footer">
          <div className="user-avatar">U</div>
          <div>
            <strong>Underwriter</strong>
            <span>Bank Officer</span>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <span className="breadcrumb">AL-WEB / WORKSPACE</span>
          </div>
          <div className="topbar-right">
            <span className="system-status">
              <span className="status-dot"></span>
              System Online
            </span>
            <div className="topbar-avatar">U</div>
          </div>
        </header>

        <div className="page-content">{children}</div>
      </main>
    </div>
  );
}


function Dashboard() {
  const stats = [
    {
      title: "Total Applications",
      value: "248",
      change: "+12.5%",
      description: "Compared to last month",
      icon: "▤",
      color: "blue",
    },
    {
      title: "Pending Reviews",
      value: "64",
      change: "26%",
      description: "Awaiting assessment",
      icon: "◷",
      color: "orange",
    },
    {
      title: "Approved Loans",
      value: "142",
      change: "+8.2%",
      description: "Successfully approved",
      icon: "✓",
      color: "green",
    },
    {
      title: "High Risk",
      value: "18",
      change: "7.3%",
      description: "Require further review",
      icon: "!",
      color: "red",
    },
  ];

  const applications = [
    {
      id: "APP-2026-001",
      name: "James Murphy",
      property: "Residential",
      amount: "€285,000",
      status: "Under Review",
      risk: "Low",
    },
    {
      id: "APP-2026-002",
      name: "Sarah O'Brien",
      property: "First-Time Buyer",
      amount: "€320,000",
      status: "Pending",
      risk: "Medium",
    },
    {
      id: "APP-2026-003",
      name: "Daniel Walsh",
      property: "Residential",
      amount: "€410,000",
      status: "Approved",
      risk: "Low",
    },
    {
      id: "APP-2026-004",
      name: "Emma Kelly",
      property: "Buy-to-Let",
      amount: "€195,000",
      status: "Under Review",
      risk: "High",
    },
    {
      id: "APP-2026-005",
      name: "Michael Byrne",
      property: "First-Time Buyer",
      amount: "€265,000",
      status: "Pending",
      risk: "Medium",
    },
  ];

  return (
    <Layout>
      <div className="dashboard-header">
        <div>
          <h1>Dashboard Overview</h1>
          <p>Welcome back, Underwriter. Here's your lending overview.</p>
        </div>
        <button className="primary-button">+ New Application</button>
      </div>

      <div className="stats-grid">
        {stats.map((stat) => (
          <div className="stat-card" key={stat.title}>
            <div className={`stat-icon ${stat.color}`}>
              {stat.icon}
            </div>
            <p>{stat.title}</p>
            <h2>{stat.value}</h2>
            <span className="stat-description">
              <strong>{stat.change}</strong> {stat.description}
            </span>
          </div>
        ))}
      </div>

      <div className="section-header">
        <div>
          <h2>Recent Applications</h2>
          <p>Monitor the latest mortgage applications.</p>
        </div>
        <NavLink to="/applications" className="view-all">
          View all →
        </NavLink>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>APPLICATION ID</th>
              <th>APPLICANT</th>
              <th>TYPE</th>
              <th>LOAN AMOUNT</th>
              <th>STATUS</th>
              <th>RISK LEVEL</th>
              <th>ACTION</th>
            </tr>
          </thead>

          <tbody>
            {applicationsData.map((app) => (
              <tr key={app.id}>
                <td className="application-id">{app.id}</td>
                <td>{app.name}</td>
                <td>{app.property}</td>
                <td className="amount">{app.amount}</td>

                <td>
                  <span className={`status-badge ${app.status.toLowerCase().replace(" ", "-")}`}>
                    {app.status}
                  </span>
                </td>

                <td>
                  <span className={`risk-badge ${app.risk.toLowerCase()}`}>
                    {app.risk}
                  </span>
                </td>

                <td>
                  <NavLink to={`/applications/${app.id}`} className="detail-link">
                    View →
                  </NavLink>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}


function Applications() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [riskFilter, setRiskFilter] = useState("All");

  const filteredApplications = applicationsData.filter((app) => {
    const matchesSearch =
      app.name.toLowerCase().includes(search.toLowerCase()) ||
      app.id.toLowerCase().includes(search.toLowerCase());

    const matchesStatus =
      statusFilter === "All" || app.status === statusFilter;

    const matchesRisk =
      riskFilter === "All" || app.risk === riskFilter;

    return matchesSearch && matchesStatus && matchesRisk;
  });

  function clearFilters() {
    setSearch("");
    setStatusFilter("All");
    setRiskFilter("All");
  }

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Loan Applications</h1>
          <p>Manage and monitor mortgage applications.</p>
        </div>

        <button className="primary-button">
          + New Application
        </button>
      </div>

      <div className="applications-summary">
        <div>
          <span>Total Applications</span>
          <strong>{applicationsData.length}</strong>
        </div>
        <div>
          <span>Pending</span>
          <strong>
            {applicationsData.filter(app => app.status === "Pending").length}
          </strong>
        </div>
        <div>
          <span>Under Review</span>
          <strong>
            {applicationsData.filter(app => app.status === "Under Review").length}
          </strong>
        </div>
        <div>
          <span>Approved</span>
          <strong>
            {applicationsData.filter(app => app.status === "Approved").length}
          </strong>
        </div>
      </div>

      <div className="application-filters">
        <input
          type="text"
          placeholder="Search by applicant or application ID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="All">All Statuses</option>
          <option value="Pending">Pending</option>
          <option value="Under Review">Under Review</option>
          <option value="Approved">Approved</option>
        </select>

        <select
          value={riskFilter}
          onChange={(e) => setRiskFilter(e.target.value)}
        >
          <option value="All">All Risk Levels</option>
          <option value="Low">Low Risk</option>
          <option value="Medium">Medium Risk</option>
          <option value="High">High Risk</option>
        </select>

        <button className="clear-button" onClick={clearFilters}>
          Clear Filters
        </button>
      </div>

      <div className="applications-results">
        Showing <strong>{filteredApplications.length}</strong> of{" "}
        <strong>{applicationsData.length}</strong> applications
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>APPLICATION ID</th>
              <th>APPLICANT</th>
              <th>TYPE</th>
              <th>LOAN AMOUNT</th>
              <th>STATUS</th>
              <th>RISK LEVEL</th>
              <th>ACTION</th>
            </tr>
          </thead>

          <tbody>
            {filteredApplications.length > 0 ? (
              filteredApplications.map((app) => (
                <tr key={app.id}>
                <td className="application-id">{app.id}</td>
                <td>{app.name}</td>
                <td>{app.property}</td>
                <td className="amount">{app.amount}</td>

                <td>
                  <span className={`status-badge ${app.status.toLowerCase().replace(" ", "-")}`}>
                    {app.status}
                  </span>
                </td>

                <td>
                  <span className={`risk-badge ${app.risk.toLowerCase()}`}>
                    {app.risk}
                  </span>
                </td>
                <td>
                  <NavLink
                  to={`/applications/${app.id}`}
                  className="detail-link">
                      View →
                  </NavLink>
                </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="empty-results">
                  No applications match your search.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}


function ApplicationDetails() {
  const { id } = useParams();

  const application = applicationsData.find((app) => app.id === id);

  if (!application) {
    return (
      <Layout>
        <h1>Application Not Found</h1>
        <p>We couldn't find that application.</p>
        <NavLink to="/applications" className="detail-link">
          ← Back to Applications
        </NavLink>
      </Layout>
    );
  }

  const money = (value) =>
    new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0,
    }).format(value);

  const loanAmount = Number(application.amount.replace(/[€,]/g, ""));
  const monthlyIncome = application.annualIncome / 12;
  const monthlyOutgoings =
    application.monthlyDebts + application.monthlyMortgage;

  const dti =
    application.annualIncome > 0
      ? (monthlyOutgoings * 12 / application.annualIncome) * 100
      : 0;

  const ltv =
    application.estimatedValuation > 0
      ? (loanAmount / application.estimatedValuation) * 100
      : 0;

  const valuationDifference =
    application.estimatedValuation - application.askingPrice;

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Application Details</h1>
          <p>
            Review the borrower, property and financial assessment.
          </p>
        </div>

        <NavLink to="/applications" className="detail-link">
          ← Back to Applications
        </NavLink>
      </div>

      <div className="detail-card">
        <div className="detail-card-header">
          <div>
            <span className="application-id">{application.id}</span>
            <h2>{application.name}</h2>
          </div>

          <span
            className={`status-badge ${application.status
              .toLowerCase()
              .replace(" ", "-")}`}
          >
            {application.status}
          </span>
        </div>

        <div className="detail-grid">
          <div>
            <span>Applicant</span>
            <strong>{application.name}</strong>
          </div>

          <div>
            <span>Application ID</span>
            <strong>{application.id}</strong>
          </div>

          <div>
            <span>Property Type</span>
            <strong>{application.property}</strong>
          </div>

          <div>
            <span>Requested Loan Amount</span>
            <strong>{money(loanAmount)}</strong>
          </div>

          <div>
            <span>Application Status</span>
            <strong>{application.status}</strong>
          </div>

          <div>
            <span>Risk Level</span>
            <strong>{application.risk}</strong>
          </div>
        </div>
      </div>

      <div className="detail-card">
        <h2>Property & Valuation</h2>
        <p>
          Illustrative figures — valuation is not connected to the ML model.
        </p>

        <div className="detail-grid">
          <div>
            <span>Seller's Asking Price</span>
            <strong>{money(application.askingPrice)}</strong>
          </div>

          <div>
            <span>Estimated ML Valuation</span>
            <strong>{money(application.estimatedValuation)}</strong>
          </div>

          <div>
            <span>Valuation Difference</span>
            <strong>
              {valuationDifference > 0 ? "+" : ""}
              {money(valuationDifference)}
            </strong>
          </div>

          <div>
            <span>Loan-to-Value (LTV)</span>
            <strong>{ltv.toFixed(1)}%</strong>
          </div>
        </div>

        <div className="valuation-comparison">
          <h3>Property Valuation Comparison</h3>

          <div className="valuation-row">
            <div className="valuation-label">
              <span>Seller's Asking Price</span>
              <strong>{money(application.askingPrice)}</strong>
            </div>

            <div className="valuation-track">
              <div
                className="valuation-bar asking"
                style={{
                  width: `${
                    (application.askingPrice /
                      Math.max(
                        application.askingPrice,
                        application.estimatedValuation
                      )) * 100
                  }%`,
                }}
              />
            </div>
          </div>

          <div className="valuation-row">
            <div className="valuation-label">
              <span>Estimated ML Valuation</span>
              <strong>{money(application.estimatedValuation)}</strong>
            </div>

            <div className="valuation-track">
              <div
                className="valuation-bar estimated"
                style={{
                  width: `${
                    (application.estimatedValuation /
                      Math.max(
                        application.askingPrice,
                        application.estimatedValuation
                      )) * 100
                  }%`,
                }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="detail-card">
        <h2>Borrower Financial Assessment</h2>
        <p>
          Illustrative figures for the AL-Web prototype, not verified
          applicant financial information.
        </p>

        <div className="detail-grid">
          <div>
            <span>Annual Income</span>
            <strong>{money(application.annualIncome)}</strong>
          </div>

          <div>
            <span>Estimated Monthly Income</span>
            <strong>{money(monthlyIncome)}</strong>
          </div>

          <div>
            <span>Existing Monthly Debts</span>
            <strong>{money(application.monthlyDebts)}</strong>
          </div>

          <div>
            <span>Estimated Monthly Mortgage</span>
            <strong>{money(application.monthlyMortgage)}</strong>
          </div>

          <div>
            <span>Total Monthly Debt & Mortgage</span>
            <strong>{money(monthlyOutgoings)}</strong>
          </div>

          <div>
            <span>Debt-to-Income (DTI)</span>
            <strong>{dti.toFixed(1)}%</strong>
          </div>
        </div>
      </div>
      
      <div className="detail-card lending-metrics">
        <h2>Lending Metrics Summary</h2>

        <p>
          Illustrative metrics calculated from the example application data.
        </p>

        <div className="lending-metrics-grid">
          <div className="lending-metric-card">
            <span>Loan-to-Value (LTV)</span>
            <strong>{ltv.toFixed(1)}%</strong>
            <p>Loan amount compared with estimated property value.</p>
          </div>

          <div className="lending-metric-card">
            <span>Debt-to-Income (DTI)</span>
            <strong>{dti.toFixed(1)}%</strong>
            <p>Estimated monthly debt and mortgage repayments relative to gross income.</p>
          </div>

          <div className="lending-metric-card">
            <span>Valuation Difference</span>
            <strong>{money(valuationDifference)}</strong>
            <p>
              {valuationDifference > 0
                ? "Estimated value is above the asking price."
                : valuationDifference < 0
                  ? "Estimated value is below the asking price."
                  : "Estimated value matches the asking price."}
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function AIAudit() {
  const agents = [
    {
      name: "Credit Risk Agent",
      role: "Credit profile assessment",
      recommendation: "Further Review",
      status: "Review Required",
      explanation:
        "The example risk assessment is low, but the applicant's credit profile must be verified before a final decision.",
    },
    {
      name: "Affordability Agent",
      role: "Income and repayment assessment",
      recommendation: "Proceed to Review",
      status: "Review Required",
      explanation:
        "The illustrative DTI is 26.8%. Income, existing debts and estimated repayments require verification.",
    },
    {
      name: "Collateral Valuation Agent",
      role: "Property valuation assessment",
      recommendation: "Proceed to Review",
      status: "Review Required",
      explanation:
        "The example property valuation is €310,000 compared with an asking price of €300,000. The valuation must be confirmed.",
    },
  ];

  const auditStages = [
    {
      stage: "1",
      title: "Application Received",
      description:
        "Application APP-2026-001 is available for assessment.",
      status: "Complete",
    },
    {
      stage: "2",
      title: "Agent Assessments",
      description:
        "Example credit risk, affordability and collateral assessments are recorded.",
      status: "Example Complete",
    },
    {
      stage: "3",
      title: "Consensus Review",
      description:
        "The combined example recommendation is to proceed to further review.",
      status: "Further Review",
    },
    {
      stage: "4",
      title: "Underwriter Decision",
      description:
        "A bank underwriter must review the evidence and make the final decision.",
      status: "Awaiting Review",
    },
  ];

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>AI Audit Console</h1>
          <p>
            Review agent assessments, consensus and decision audit trails.
          </p>
        </div>
      </div>

      <div className="detail-card">
        <h2>AI Assessment Overview</h2>
        <p>
          Illustrative assessment for APP-2026-001. No live AI agents are
          connected.
        </p>

        <div className="detail-grid">
          <div>
            <span>Application ID</span>
            <strong>APP-2026-001</strong>
          </div>
          <div>
            <span>Overall Recommendation</span>
            <strong>Further Review</strong>
          </div>
          <div>
            <span>Example Risk Assessment</span>
            <strong>Low Risk</strong>
          </div>
          <div>
            <span>Assessment Status</span>
            <strong>Awaiting Human Review</strong>
          </div>
        </div>
      </div>

      <div className="detail-card">
        <h2>Agent Assessments</h2>
        <p>
          Example outputs showing how separate agents could assess different
          parts of a mortgage application.
        </p>

        <div className="agent-grid">
          {agents.map((agent) => (
            <div className="agent-card" key={agent.name}>
              <div className="agent-card-header">
                <h3>{agent.name}</h3>
                <span className="risk-badge medium">
                  {agent.status}
                </span>
              </div>

              <p className="agent-role">{agent.role}</p>

              <div className="agent-recommendation">
                <span>Recommendation</span>
                <strong>{agent.recommendation}</strong>
              </div>

              <div className="agent-explanation">
                <span>Assessment Explanation</span>
                <p>{agent.explanation}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="detail-card">
        <h2>Agent Consensus</h2>
        <p>
          The example agents identify checks that should be completed before
          the application progresses to a final lending decision.
        </p>

        <div className="consensus-summary">
          <div>
            <span>Agents Represented</span>
            <strong>{agents.length}</strong>
          </div>
          <div>
            <span>Overall Outcome</span>
            <strong>Further Review</strong>
          </div>
          <div>
            <span>Final Decision</span>
            <strong>Pending Underwriter</strong>
          </div>
        </div>

        <p className="prototype-notice">
          This is a demonstration summary, not a calculated AI consensus.
          The displayed recommendations are predefined examples.
        </p>
      </div>

      <div className="detail-card">
        <h2>Decision Audit Trail</h2>
        <p>
          Example sequence of stages from application receipt to human review.
        </p>

        <div className="audit-timeline">
          {auditStages.map((item) => (
            <div className="audit-stage" key={item.stage}>
              <div className="audit-stage-number">{item.stage}</div>

              <div className="audit-stage-content">
                <div className="audit-stage-header">
                  <h3>{item.title}</h3>
                  <span className="audit-stage-status">
                    {item.status}
                  </span>
                </div>

                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}


function StressTesting() {
  const [rateShock, setRateShock] = useState(100);
  const [propertyDecline, setPropertyDecline] = useState(10);
  const [incomeReduction, setIncomeReduction] = useState(5);

  
  // Illustrative baseline using all example applications.
  const portfolio = applicationsData.map((app) => ({
    loan: Number(app.amount.replace(/[€,]/g, "")),
    value: app.estimatedValuation,
    income: app.annualIncome,
    debts: app.monthlyDebts,
    mortgage: app.monthlyMortgage,
  }));

  const totalLoans = portfolio.reduce((sum, app) => sum + app.loan, 0);
  const totalPropertyValue = portfolio.reduce(
    (sum, app) => sum + app.value,
    0
  );
  const totalAnnualIncome = portfolio.reduce(
    (sum, app) => sum + app.income,
    0
  );
  const totalMonthlyDebts = portfolio.reduce(
    (sum, app) => sum + app.debts,
    0
  );
  const totalMonthlyMortgage = portfolio.reduce(
    (sum, app) => sum + app.mortgage,
    0
  );

  // Simplified repayment sensitivity for demonstration only.
  const stressedMortgage =
    totalMonthlyMortgage * (1 + (rateShock / 100) * 0.04);

  const stressedPropertyValue =
    totalPropertyValue * (1 - propertyDecline / 100);

  const stressedAnnualIncome =
    totalAnnualIncome * (1 - incomeReduction / 100);

  const baselineLTV =
    (totalLoans / totalPropertyValue) * 100;

  const stressedLTV =
    (totalLoans / stressedPropertyValue) * 100;

  const baselineDTI =
    ((totalMonthlyDebts + totalMonthlyMortgage) * 12 /
      totalAnnualIncome) * 100;

  const stressedDTI =
    ((totalMonthlyDebts + stressedMortgage) * 12 /
      stressedAnnualIncome) * 100;

  const money = (value) =>
    new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0,
    }).format(value);

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Stress Testing</h1>
          <p>
            Simulate how interest rates, property values and income
            changes could affect a loan application.
          </p>
        </div>
      </div>

      <div className="detail-card">
        <h2>Scenario Controls</h2>
        <p>
          Adjust the conditions below to recalculate the illustrative
          assessment across all five example applications.
        </p>

        <div className="stress-controls">
          <div className="stress-control">
            <label htmlFor="rate-shock">
              Interest-Rate Shock
            </label>
            <select
              id="rate-shock"
              value={rateShock}
              onChange={(event) =>
                setRateShock(Number(event.target.value))
              }
            >
              <option value={100}>+100 basis points (+1%)</option>
              <option value={200}>+200 basis points (+2%)</option>
              <option value={300}>+300 basis points (+3%)</option>
            </select>
            <p>Changes the estimated monthly mortgage repayment.</p>
          </div>

          <div className="stress-control">
            <label htmlFor="property-decline">
              Property Value Decline
            </label>
            <select
              id="property-decline"
              value={propertyDecline}
              onChange={(event) =>
                setPropertyDecline(Number(event.target.value))
              }
            >
              <option value={0}>0% decline</option>
              <option value={5}>5% decline</option>
              <option value={10}>10% decline</option>
              <option value={15}>15% decline</option>
              <option value={20}>20% decline</option>
            </select>
            <p>Reduces the estimated property value.</p>
          </div>

          <div className="stress-control">
            <label htmlFor="income-reduction">
              Annual Income Reduction
            </label>
            <select
              id="income-reduction"
              value={incomeReduction}
              onChange={(event) =>
                setIncomeReduction(Number(event.target.value))
              }
            >
              <option value={0}>0% reduction</option>
              <option value={5}>5% reduction</option>
              <option value={10}>10% reduction</option>
              <option value={15}>15% reduction</option>
              <option value={20}>20% reduction</option>
            </select>
            <p>Reduces the income used in the DTI calculation.</p>
          </div>
        </div>
      </div>

      <div className="detail-card">
        <h2>Portfolio Stress Test Results</h2>
        <p>
          Compare the baseline figures with the results after applying
          the selected scenario.
        </p>

        <div className="stress-results-grid">
          <div className="stress-result-card">
            <span>Monthly Mortgage</span>
            <strong>{money(stressedMortgage)}</strong>
            <p>Baseline: {money(totalMonthlyMortgage)}</p>
            <small>
              Change: +{money(stressedMortgage - totalMonthlyMortgage)}
            </small>
          </div>

          <div className="stress-result-card">
            <span>Estimated Property Value</span>
            <strong>{money(stressedPropertyValue)}</strong>
            <p>Baseline: {money(totalPropertyValue)}</p>
            <small>
              Change: -{money(totalPropertyValue - stressedPropertyValue)}
            </small>
          </div>

          <div className="stress-result-card">
            <span>Annual Income</span>
            <strong>{money(stressedAnnualIncome)}</strong>
            <p>Baseline: {money(totalAnnualIncome)}</p>
            <small>
              Change: -{money(totalAnnualIncome - stressedAnnualIncome)}
            </small>
          </div>
        </div>
      </div>

      <div className="detail-card">
        <h2>Portfolio Risk Indicators - All Example Applications</h2>
        <p>
          These ratios illustrate how the selected scenario affects
          this example application.
        </p>

        <div className="stress-results-grid">
          <div className="stress-result-card">
            <span>Loan-to-Value (LTV)</span>
            <strong>{stressedLTV.toFixed(1)}%</strong>
            <p>Baseline: {baselineLTV.toFixed(1)}%</p>
          </div>

          <div className="stress-result-card">
            <span>Debt-to-Income (DTI)</span>
            <strong>{stressedDTI.toFixed(1)}%</strong>
            <p>Baseline: {baselineDTI.toFixed(1)}%</p>
          </div>

          <div className="stress-result-card">
            <span>Monthly Debt & Mortgage</span>
            <strong>
              {money(totalMonthlyDebts + stressedMortgage)}
            </strong>
            <p>
              Baseline: {money(totalMonthlyDebts + totalMonthlyMortgage)}
            </p>
          </div>
        </div>
      </div>

      <div className="detail-card">
        <h2>Simulation Notes</h2>
        <p>
          The figures are illustrative sensitivity estimates, not
          verified lending outcomes. The interest-rate adjustment uses
          a simplified multiplier rather than a mortgage amortisation
          model. Only one example application is included; portfolio-wide
          aggregation and real financial data integration remain future work.
        </p>
      </div>
    </Layout>
  );
}

function Approval() {
  const [selectedId, setSelectedId] = useState(applicationsData[0].id);
  const [decision, setDecision] = useState("Awaiting Decision");

  const application = applicationsData.find(
    (app) => app.id === selectedId
  );

  function makeDecision(newDecision) {
    setDecision(newDecision);
  }

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Loan Approval</h1>
          <p>Review an application and record an underwriter decision.</p>
        </div>
      </div>

      <div className="detail-card">
        <h2>Select Application</h2>

        <select
          className="approval-select"
          value={selectedId}
          onChange={(e) => {
            setSelectedId(e.target.value);
            setDecision("Awaiting Decision");
          }}
        >
          {applicationsData.map((app) => (
            <option key={app.id} value={app.id}>
              {app.id} — {app.name}
            </option>
          ))}
        </select>

        {application && (
          <>
            <div className="detail-grid">
              <div>
                <span>Applicant</span>
                <strong>{application.name}</strong>
              </div>
              <div>
                <span>Application ID</span>
                <strong>{application.id}</strong>
              </div>
              <div>
                <span>Property Type</span>
                <strong>{application.property}</strong>
              </div>
              <div>
                <span>Loan Amount</span>
                <strong>{application.amount}</strong>
              </div>
              <div>
                <span>Current Status</span>
                <strong>{application.status}</strong>
              </div>
              <div>
                <span>Risk Level</span>
                <strong>{application.risk}</strong>
              </div>
            </div>

            <div className="approval-decision">
              <h2>Underwriter Decision</h2>
              <p>
                Current decision: <strong>{decision}</strong>
              </p>

              <div className="approval-actions">
                <button
                  className="approve-button"
                  onClick={() => makeDecision("Approved")}
                >
                  Approve
                </button>

                <button
                  className="reject-button"
                  onClick={() => makeDecision("Rejected")}
                >
                  Reject
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}




function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/applications" element={<Applications />} />
        <Route path="/applications/:id" element={<ApplicationDetails />} />
        <Route path="/ai-audit" element={<AIAudit />} />
        <Route path="/stress-testing" element={<StressTesting />} />
        <Route path="/approval" element={<Approval />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

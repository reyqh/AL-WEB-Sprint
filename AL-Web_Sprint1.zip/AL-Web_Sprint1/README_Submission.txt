# AL-Web Sprint 1 Submission

This folder contains a draft Sprint 1 documentation package and the AL-Web source code supplied for review.

## Contents
- `01_Sprint_Backlog.xlsx` — candidate sprint backlog and scope notes.
- `02_Use_Cases_and_User_Stories.docx` — use cases and related user stories.
- `03_Wireframes_and_Designs.docx` — low-fidelity wireframes and design notes.
- `04_Test_Cases.xlsx` — proposed functional test cases. They are marked Not run until executed.
- `05_Sprint_Retrospective.docx` — retrospective draft for team review.
- `06_Code/AL-Web/` — source code and project configuration, excluding `node_modules`.

## Run the application
1. Install a compatible Node.js version.
2. Open a terminal in `06_Code/AL-Web`.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite.

S
